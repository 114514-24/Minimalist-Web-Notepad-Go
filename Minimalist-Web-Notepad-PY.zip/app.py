# app.py
import os
import random
import string
import argparse
from flask import Flask, request, render_template, redirect, url_for, jsonify, send_from_directory

app = Flask(__name__, static_folder='static')

# 确保临时目录存在
if not os.path.exists('_tmp_'):
    os.makedirs('_tmp_')

def random_string(length):
    """生成指定长度的随机字符串"""
    charset = string.ascii_letters + string.digits
    return ''.join(random.choice(charset) for _ in range(length))

@app.route('/')
def index():
    """根路径重定向到随机生成的路径"""
    random_str = random_string(app.config.get('RANDOM_LENGTH', 10))
    return redirect(url_for('note', path=random_str))

@app.route('/<path:path>')
def note(path):
    """显示指定路径的笔记页面"""
    file_path = os.path.join('_tmp_', path)
    
    # 检查文件是否存在，如果不存在则创建
    if not os.path.exists(file_path):
        # 确保目录存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        # 创建空文件
        with open(file_path, 'w') as f:
            f.write('')
    
    # 读取文件内容
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            body = f.read()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    return render_template('index.html', title=path, body=body)

@app.route('/<path:path>', methods=['POST'])
def save_note(path):
    """保存指定路径的笔记内容"""
    # 读取POST请求的内容
    body = request.get_data()
    
    # 定义文件路径
    file_path = os.path.join('_tmp_', path)
    
    # 确保_tmp_目录存在
    os.makedirs('_tmp_', exist_ok=True)
    
    # 写入文件
    try:
        with open(file_path, 'wb') as f:
            f.write(body)
    except Exception as e:
        return jsonify({"error": "Error writing to file"}), 500
    
    # 如果文件内容为空，则删除文件
    try:
        with open(file_path, 'rb') as f:
            file_content = f.read()
        if len(file_content) == 0:
            os.remove(file_path)
    except Exception as e:
        pass  # 忽略删除文件时的错误
    
    # 如果请求内容为空，也删除文件
    if len(body) == 0:
        if os.path.exists(file_path):
            os.remove(file_path)
        return jsonify({"status": "Success"})
    
    # 返回成功的响应
    return jsonify({"status": "Success"})

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-l', '--length', type=int, default=10, help='random int long')
    parser.add_argument('-p', '--port', type=str, default=':80', help='port to listen on')
    
    args = parser.parse_args()
    
    # 设置随机字符串长度
    app.config['RANDOM_LENGTH'] = args.length
    
    # 解析端口号
    port = args.port
    if port.startswith(':'):
        port = port[1:]
    
    app.run(host='0.0.0.0', port=int(port), debug=False)